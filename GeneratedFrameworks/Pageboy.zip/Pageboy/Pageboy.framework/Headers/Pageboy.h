//
//  Pageboy.h
//  Pageboy
//
//  Created by Merrick Sapsford on 25/07/2017.
//  Copyright © 2018 UI At Six. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Pageboy.
FOUNDATION_EXPORT double PageboyVersionNumber;

//! Project version string for Pageboy.
FOUNDATION_EXPORT const unsigned char PageboyVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Pageboy/PublicHeader.h>


